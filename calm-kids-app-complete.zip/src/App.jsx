import React from 'react';
import './App.css';

function App() {
  return (
    <div className="app">
      <h1>Calm Kids</h1>
      <p>Essential Oil Blends to Ease Anxiety, Stress & Depression</p>

      <div className="blend">
        <h2>🌿 Bedtime Blend</h2>
        <p>2 drops Lavender • 1 drop Roman Chamomile • 1 drop Cedarwood</p>
      </div>

      <div className="blend">
        <h2>💧 Anxiety Relief</h2>
        <p>2 drops Frankincense • 2 drops Bergamot • 1 drop Ylang Ylang</p>
      </div>

      <div className="blend">
        <h2>🌸 Emotional Support</h2>
        <p>1 drop Rose • 2 drops Orange • 2 drops Lavender</p>
      </div>

      <a href="https://your-payhip-link" className="btn" target="_blank" rel="noopener noreferrer">
        💜 Buy the Ebook on Payhip
      </a>
    </div>
  );
}

export default App;