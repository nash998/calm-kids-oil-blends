# Calm Kids App 🌿

A colorful and calming web app to help parents ease anxiety, stress, and depression in children using essential oil blends.

## 🌟 Features

- Kid-safe essential oil blend recipes  
- Clean, mobile-friendly design  
- Link to purchase the ebook on Payhip  
- Installable like a real app (PWA support)  

## 🔧 How to Run Locally

Make sure you have [Node.js](https://nodejs.org/) installed, then run:

```bash
npm install
npm run start
```

This will start a local server so you can preview the app.

## 📦 Build for Production

To create a production-ready version for deployment, run:

```bash
npm run build
```

## 🚀 Deployment

You can deploy the app for free using [Netlify](https://www.netlify.com/):

1. Create a free Netlify account.  
2. Connect your GitHub repository.  
3. Set the build command to `npm run build`.  
4. Set the publish directory to `build`.  
5. Click **Deploy** and your app will be live!

## 🔗 Buy the Ebook

[Purchase on Payhip](https://your-payhip-link)

## 👩‍💻 Author

Nashawnda Brimmer — Helping families heal naturally 💜

---